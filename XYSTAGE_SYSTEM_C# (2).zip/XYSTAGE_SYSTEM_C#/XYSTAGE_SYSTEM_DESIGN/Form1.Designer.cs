﻿namespace XYSTAGE_SYSTEM_DESIGN
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pl_stage = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.bt_disconnect = new System.Windows.Forms.Button();
            this.bt_connect = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bt_Graph = new System.Windows.Forms.Button();
            this.bt_stop = new System.Windows.Forms.Button();
            this.bt_Normal_Move = new System.Windows.Forms.Button();
            this.tb_Normal_Move_YPos = new System.Windows.Forms.TextBox();
            this.tb_Normal_Move_XPos = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.rb_Line = new System.Windows.Forms.RadioButton();
            this.rb_CAM = new System.Windows.Forms.RadioButton();
            this.rb_PM = new System.Windows.Forms.RadioButton();
            this.rb_PTP = new System.Windows.Forms.RadioButton();
            this.rb_CP = new System.Windows.Forms.RadioButton();
            this.gb_xGroup = new System.Windows.Forms.GroupBox();
            this.bt_xEstop_Clr = new System.Windows.Forms.Button();
            this.bt_xServoOn = new System.Windows.Forms.Button();
            this.bt_xAlarmClr = new System.Windows.Forms.Button();
            this.bt_xHome = new System.Windows.Forms.Button();
            this.bt_xPosClr = new System.Windows.Forms.Button();
            this.bt_xEstop = new System.Windows.Forms.Button();
            this.tb_xVel = new System.Windows.Forms.TextBox();
            this.tb_xAcc = new System.Windows.Forms.TextBox();
            this.tb_xDec = new System.Windows.Forms.TextBox();
            this.tb_xCommandPos = new System.Windows.Forms.TextBox();
            this.tb_xFeedPos = new System.Windows.Forms.TextBox();
            this.tb_xFeedVel = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tb_xPGain = new System.Windows.Forms.TextBox();
            this.tb_xDGain = new System.Windows.Forms.TextBox();
            this.tb_xIGain = new System.Windows.Forms.TextBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.bt_PM_radiusSet = new System.Windows.Forms.Button();
            this.tb_PM_radius = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.bt_PM_numSet = new System.Windows.Forms.Button();
            this.tb_PM_num = new System.Windows.Forms.TextBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.bt_yEstop_Clr = new System.Windows.Forms.Button();
            this.bt_yServoOn = new System.Windows.Forms.Button();
            this.bt_yAlarmClr = new System.Windows.Forms.Button();
            this.bt_yHome = new System.Windows.Forms.Button();
            this.bt_yPosClr = new System.Windows.Forms.Button();
            this.bt_yEstop = new System.Windows.Forms.Button();
            this.tb_yVel = new System.Windows.Forms.TextBox();
            this.tb_yAcc = new System.Windows.Forms.TextBox();
            this.tb_yDec = new System.Windows.Forms.TextBox();
            this.tb_yCommandPos = new System.Windows.Forms.TextBox();
            this.tb_yFeedPos = new System.Windows.Forms.TextBox();
            this.tb_yFeedVel = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.tb_yPGain = new System.Windows.Forms.TextBox();
            this.tb_yDGain = new System.Windows.Forms.TextBox();
            this.tb_yIGain = new System.Windows.Forms.TextBox();
            this.lb_connect_state = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.gb_xGroup.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.SuspendLayout();
            // 
            // pl_stage
            // 
            this.pl_stage.BackColor = System.Drawing.SystemColors.Window;
            this.pl_stage.Location = new System.Drawing.Point(42, 186);
            this.pl_stage.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pl_stage.Name = "pl_stage";
            this.pl_stage.Size = new System.Drawing.Size(629, 688);
            this.pl_stage.TabIndex = 0;
            this.pl_stage.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pl_stage_MouseDown);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Silver;
            this.groupBox1.Controls.Add(this.bt_disconnect);
            this.groupBox1.Controls.Add(this.bt_connect);
            this.groupBox1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(42, 84);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox1.Size = new System.Drawing.Size(153, 95);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "TwinCAT 연결";
            // 
            // bt_disconnect
            // 
            this.bt_disconnect.Location = new System.Drawing.Point(25, 59);
            this.bt_disconnect.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_disconnect.Name = "bt_disconnect";
            this.bt_disconnect.Size = new System.Drawing.Size(107, 29);
            this.bt_disconnect.TabIndex = 1;
            this.bt_disconnect.Text = "DisConnect";
            this.bt_disconnect.UseVisualStyleBackColor = true;
            // 
            // bt_connect
            // 
            this.bt_connect.FlatAppearance.BorderSize = 5;
            this.bt_connect.Location = new System.Drawing.Point(25, 25);
            this.bt_connect.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_connect.Name = "bt_connect";
            this.bt_connect.Size = new System.Drawing.Size(107, 29);
            this.bt_connect.TabIndex = 0;
            this.bt_connect.Text = "Connect";
            this.bt_connect.UseVisualStyleBackColor = true;
            this.bt_connect.Click += new System.EventHandler(this.bt_connect_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Silver;
            this.groupBox2.Controls.Add(this.bt_Graph);
            this.groupBox2.Controls.Add(this.bt_stop);
            this.groupBox2.Controls.Add(this.bt_Normal_Move);
            this.groupBox2.Controls.Add(this.tb_Normal_Move_YPos);
            this.groupBox2.Controls.Add(this.tb_Normal_Move_XPos);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Location = new System.Drawing.Point(202, 40);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox2.Size = new System.Drawing.Size(237, 139);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "좌표이동";
            // 
            // bt_Graph
            // 
            this.bt_Graph.Location = new System.Drawing.Point(80, 85);
            this.bt_Graph.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_Graph.Name = "bt_Graph";
            this.bt_Graph.Size = new System.Drawing.Size(63, 31);
            this.bt_Graph.TabIndex = 6;
            this.bt_Graph.Text = "그리기";
            this.bt_Graph.UseVisualStyleBackColor = true;
            this.bt_Graph.Click += new System.EventHandler(this.bt_Graph_Click);
            // 
            // bt_stop
            // 
            this.bt_stop.Location = new System.Drawing.Point(150, 85);
            this.bt_stop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_stop.Name = "bt_stop";
            this.bt_stop.Size = new System.Drawing.Size(63, 31);
            this.bt_stop.TabIndex = 5;
            this.bt_stop.Text = "Stop";
            this.bt_stop.UseVisualStyleBackColor = true;
            this.bt_stop.Click += new System.EventHandler(this.bt_stop_Click);
            // 
            // bt_Normal_Move
            // 
            this.bt_Normal_Move.Location = new System.Drawing.Point(150, 16);
            this.bt_Normal_Move.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_Normal_Move.Name = "bt_Normal_Move";
            this.bt_Normal_Move.Size = new System.Drawing.Size(63, 61);
            this.bt_Normal_Move.TabIndex = 4;
            this.bt_Normal_Move.Text = "Move";
            this.bt_Normal_Move.UseVisualStyleBackColor = true;
            this.bt_Normal_Move.Click += new System.EventHandler(this.bt_Normal_Move_Click);
            // 
            // tb_Normal_Move_YPos
            // 
            this.tb_Normal_Move_YPos.Location = new System.Drawing.Point(82, 51);
            this.tb_Normal_Move_YPos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Normal_Move_YPos.Name = "tb_Normal_Move_YPos";
            this.tb_Normal_Move_YPos.Size = new System.Drawing.Size(60, 25);
            this.tb_Normal_Move_YPos.TabIndex = 3;
            this.tb_Normal_Move_YPos.Text = "50";
            // 
            // tb_Normal_Move_XPos
            // 
            this.tb_Normal_Move_XPos.Location = new System.Drawing.Point(82, 19);
            this.tb_Normal_Move_XPos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_Normal_Move_XPos.Name = "tb_Normal_Move_XPos";
            this.tb_Normal_Move_XPos.Size = new System.Drawing.Size(60, 25);
            this.tb_Normal_Move_XPos.TabIndex = 2;
            this.tb_Normal_Move_XPos.Text = "50";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "Y좌표 :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "X좌표 : ";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Silver;
            this.groupBox3.Controls.Add(this.rb_Line);
            this.groupBox3.Controls.Add(this.rb_CAM);
            this.groupBox3.Controls.Add(this.rb_PM);
            this.groupBox3.Controls.Add(this.rb_PTP);
            this.groupBox3.Controls.Add(this.rb_CP);
            this.groupBox3.Location = new System.Drawing.Point(446, 84);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox3.Size = new System.Drawing.Size(225, 95);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "동작모드";
            // 
            // rb_Line
            // 
            this.rb_Line.AutoSize = true;
            this.rb_Line.Location = new System.Drawing.Point(153, 25);
            this.rb_Line.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rb_Line.Name = "rb_Line";
            this.rb_Line.Size = new System.Drawing.Size(55, 19);
            this.rb_Line.TabIndex = 4;
            this.rb_Line.TabStop = true;
            this.rb_Line.Text = "Line";
            this.rb_Line.UseVisualStyleBackColor = true;
            // 
            // rb_CAM
            // 
            this.rb_CAM.AutoSize = true;
            this.rb_CAM.Location = new System.Drawing.Point(82, 59);
            this.rb_CAM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rb_CAM.Name = "rb_CAM";
            this.rb_CAM.Size = new System.Drawing.Size(59, 19);
            this.rb_CAM.TabIndex = 3;
            this.rb_CAM.TabStop = true;
            this.rb_CAM.Text = "CAM";
            this.rb_CAM.UseVisualStyleBackColor = true;
            this.rb_CAM.CheckedChanged += new System.EventHandler(this.rb_CAM_CheckedChanged);
            // 
            // rb_PM
            // 
            this.rb_PM.AutoSize = true;
            this.rb_PM.Location = new System.Drawing.Point(30, 59);
            this.rb_PM.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rb_PM.Name = "rb_PM";
            this.rb_PM.Size = new System.Drawing.Size(50, 19);
            this.rb_PM.TabIndex = 2;
            this.rb_PM.TabStop = true;
            this.rb_PM.Text = "PM";
            this.rb_PM.UseVisualStyleBackColor = true;
            // 
            // rb_PTP
            // 
            this.rb_PTP.AutoSize = true;
            this.rb_PTP.Location = new System.Drawing.Point(82, 25);
            this.rb_PTP.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rb_PTP.Name = "rb_PTP";
            this.rb_PTP.Size = new System.Drawing.Size(56, 19);
            this.rb_PTP.TabIndex = 1;
            this.rb_PTP.TabStop = true;
            this.rb_PTP.Text = "PTP";
            this.rb_PTP.UseVisualStyleBackColor = true;
            // 
            // rb_CP
            // 
            this.rb_CP.AutoSize = true;
            this.rb_CP.Location = new System.Drawing.Point(30, 25);
            this.rb_CP.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.rb_CP.Name = "rb_CP";
            this.rb_CP.Size = new System.Drawing.Size(48, 19);
            this.rb_CP.TabIndex = 0;
            this.rb_CP.TabStop = true;
            this.rb_CP.Text = "CP";
            this.rb_CP.UseVisualStyleBackColor = true;
            // 
            // gb_xGroup
            // 
            this.gb_xGroup.BackColor = System.Drawing.Color.Silver;
            this.gb_xGroup.Controls.Add(this.bt_xEstop_Clr);
            this.gb_xGroup.Controls.Add(this.bt_xServoOn);
            this.gb_xGroup.Controls.Add(this.bt_xAlarmClr);
            this.gb_xGroup.Controls.Add(this.bt_xHome);
            this.gb_xGroup.Controls.Add(this.bt_xPosClr);
            this.gb_xGroup.Controls.Add(this.bt_xEstop);
            this.gb_xGroup.Controls.Add(this.tb_xVel);
            this.gb_xGroup.Controls.Add(this.tb_xAcc);
            this.gb_xGroup.Controls.Add(this.tb_xDec);
            this.gb_xGroup.Controls.Add(this.tb_xCommandPos);
            this.gb_xGroup.Controls.Add(this.tb_xFeedPos);
            this.gb_xGroup.Controls.Add(this.tb_xFeedVel);
            this.gb_xGroup.Controls.Add(this.groupBox4);
            this.gb_xGroup.Controls.Add(this.groupBox5);
            this.gb_xGroup.Controls.Add(this.groupBox6);
            this.gb_xGroup.ForeColor = System.Drawing.Color.Black;
            this.gb_xGroup.Location = new System.Drawing.Point(678, 116);
            this.gb_xGroup.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gb_xGroup.Name = "gb_xGroup";
            this.gb_xGroup.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.gb_xGroup.Size = new System.Drawing.Size(389, 375);
            this.gb_xGroup.TabIndex = 33;
            this.gb_xGroup.TabStop = false;
            this.gb_xGroup.Text = "X축";
            // 
            // bt_xEstop_Clr
            // 
            this.bt_xEstop_Clr.Location = new System.Drawing.Point(263, 216);
            this.bt_xEstop_Clr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_xEstop_Clr.Name = "bt_xEstop_Clr";
            this.bt_xEstop_Clr.Size = new System.Drawing.Size(86, 29);
            this.bt_xEstop_Clr.TabIndex = 35;
            this.bt_xEstop_Clr.Text = "STOP Clr";
            this.bt_xEstop_Clr.UseVisualStyleBackColor = true;
            this.bt_xEstop_Clr.Click += new System.EventHandler(this.bt_xEstop_Clr_Click);
            // 
            // bt_xServoOn
            // 
            this.bt_xServoOn.Location = new System.Drawing.Point(264, 51);
            this.bt_xServoOn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_xServoOn.Name = "bt_xServoOn";
            this.bt_xServoOn.Size = new System.Drawing.Size(86, 29);
            this.bt_xServoOn.TabIndex = 0;
            this.bt_xServoOn.Text = "Servo On";
            this.bt_xServoOn.UseVisualStyleBackColor = true;
            this.bt_xServoOn.Click += new System.EventHandler(this.bt_xServoOn_Click);
            // 
            // bt_xAlarmClr
            // 
            this.bt_xAlarmClr.Location = new System.Drawing.Point(264, 85);
            this.bt_xAlarmClr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_xAlarmClr.Name = "bt_xAlarmClr";
            this.bt_xAlarmClr.Size = new System.Drawing.Size(86, 29);
            this.bt_xAlarmClr.TabIndex = 1;
            this.bt_xAlarmClr.Text = "Alarm Clr";
            this.bt_xAlarmClr.UseVisualStyleBackColor = true;
            // 
            // bt_xHome
            // 
            this.bt_xHome.Location = new System.Drawing.Point(264, 119);
            this.bt_xHome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_xHome.Name = "bt_xHome";
            this.bt_xHome.Size = new System.Drawing.Size(86, 29);
            this.bt_xHome.TabIndex = 2;
            this.bt_xHome.Text = "Home";
            this.bt_xHome.UseVisualStyleBackColor = true;
            this.bt_xHome.Click += new System.EventHandler(this.bt_xHome_Click);
            // 
            // bt_xPosClr
            // 
            this.bt_xPosClr.Location = new System.Drawing.Point(264, 174);
            this.bt_xPosClr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_xPosClr.Name = "bt_xPosClr";
            this.bt_xPosClr.Size = new System.Drawing.Size(86, 29);
            this.bt_xPosClr.TabIndex = 3;
            this.bt_xPosClr.Text = "Pos Clr";
            this.bt_xPosClr.UseVisualStyleBackColor = true;
            this.bt_xPosClr.Click += new System.EventHandler(this.bt_xPosClr_Click);
            // 
            // bt_xEstop
            // 
            this.bt_xEstop.Location = new System.Drawing.Point(263, 260);
            this.bt_xEstop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_xEstop.Name = "bt_xEstop";
            this.bt_xEstop.Size = new System.Drawing.Size(86, 29);
            this.bt_xEstop.TabIndex = 5;
            this.bt_xEstop.Text = "ESTOP";
            this.bt_xEstop.UseVisualStyleBackColor = true;
            this.bt_xEstop.Click += new System.EventHandler(this.bt_xEstop_Click);
            // 
            // tb_xVel
            // 
            this.tb_xVel.Location = new System.Drawing.Point(162, 51);
            this.tb_xVel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_xVel.Name = "tb_xVel";
            this.tb_xVel.Size = new System.Drawing.Size(81, 25);
            this.tb_xVel.TabIndex = 12;
            this.tb_xVel.Text = "1000";
            // 
            // tb_xAcc
            // 
            this.tb_xAcc.Location = new System.Drawing.Point(162, 85);
            this.tb_xAcc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_xAcc.Name = "tb_xAcc";
            this.tb_xAcc.Size = new System.Drawing.Size(81, 25);
            this.tb_xAcc.TabIndex = 13;
            this.tb_xAcc.Text = "1000";
            // 
            // tb_xDec
            // 
            this.tb_xDec.Location = new System.Drawing.Point(162, 121);
            this.tb_xDec.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_xDec.Name = "tb_xDec";
            this.tb_xDec.Size = new System.Drawing.Size(81, 25);
            this.tb_xDec.TabIndex = 14;
            this.tb_xDec.Text = "1000";
            // 
            // tb_xCommandPos
            // 
            this.tb_xCommandPos.Location = new System.Drawing.Point(162, 182);
            this.tb_xCommandPos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_xCommandPos.Name = "tb_xCommandPos";
            this.tb_xCommandPos.ReadOnly = true;
            this.tb_xCommandPos.Size = new System.Drawing.Size(81, 25);
            this.tb_xCommandPos.TabIndex = 15;
            // 
            // tb_xFeedPos
            // 
            this.tb_xFeedPos.Location = new System.Drawing.Point(162, 216);
            this.tb_xFeedPos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_xFeedPos.Name = "tb_xFeedPos";
            this.tb_xFeedPos.ReadOnly = true;
            this.tb_xFeedPos.Size = new System.Drawing.Size(81, 25);
            this.tb_xFeedPos.TabIndex = 16;
            // 
            // tb_xFeedVel
            // 
            this.tb_xFeedVel.Location = new System.Drawing.Point(162, 250);
            this.tb_xFeedVel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_xFeedVel.Name = "tb_xFeedVel";
            this.tb_xFeedVel.ReadOnly = true;
            this.tb_xFeedVel.Size = new System.Drawing.Size(81, 25);
            this.tb_xFeedVel.TabIndex = 17;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.label5);
            this.groupBox4.Location = new System.Drawing.Point(32, 29);
            this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox4.Size = new System.Drawing.Size(225, 130);
            this.groupBox4.TabIndex = 29;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "[파라미터]";
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label3.Location = new System.Drawing.Point(7, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 29);
            this.label3.TabIndex = 32;
            this.label3.Text = "Deceleration";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label4.Location = new System.Drawing.Point(7, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(98, 29);
            this.label4.TabIndex = 31;
            this.label4.Text = "Acceleration";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label5.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label5.Location = new System.Drawing.Point(7, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 29);
            this.label5.TabIndex = 30;
            this.label5.Text = "Velocity";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Location = new System.Drawing.Point(32, 164);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox5.Size = new System.Drawing.Size(225, 125);
            this.groupBox5.TabIndex = 33;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "[모니터링]";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label6.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label6.Location = new System.Drawing.Point(7, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(98, 29);
            this.label6.TabIndex = 35;
            this.label6.Text = "Feedback Vel";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label7.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label7.Location = new System.Drawing.Point(7, 51);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 29);
            this.label7.TabIndex = 34;
            this.label7.Text = "Feedback Pos";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label8.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label8.Location = new System.Drawing.Point(7, 19);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(117, 29);
            this.label8.TabIndex = 33;
            this.label8.Text = "Command Pos";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.label11);
            this.groupBox6.Controls.Add(this.tb_xPGain);
            this.groupBox6.Controls.Add(this.tb_xDGain);
            this.groupBox6.Controls.Add(this.tb_xIGain);
            this.groupBox6.Location = new System.Drawing.Point(32, 296);
            this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox6.Size = new System.Drawing.Size(318, 70);
            this.groupBox6.TabIndex = 34;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "[모니터링 PID]";
            // 
            // label9
            // 
            this.label9.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label9.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label9.Location = new System.Drawing.Point(210, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(27, 26);
            this.label9.TabIndex = 38;
            this.label9.Text = "D :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label10.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label10.Location = new System.Drawing.Point(106, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(29, 26);
            this.label10.TabIndex = 37;
            this.label10.Text = "I :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label11.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label11.Location = new System.Drawing.Point(7, 28);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(27, 26);
            this.label11.TabIndex = 36;
            this.label11.Text = "P :";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tb_xPGain
            // 
            this.tb_xPGain.Location = new System.Drawing.Point(38, 25);
            this.tb_xPGain.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_xPGain.Name = "tb_xPGain";
            this.tb_xPGain.ReadOnly = true;
            this.tb_xPGain.Size = new System.Drawing.Size(62, 25);
            this.tb_xPGain.TabIndex = 28;
            // 
            // tb_xDGain
            // 
            this.tb_xDGain.Location = new System.Drawing.Point(240, 25);
            this.tb_xDGain.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_xDGain.Name = "tb_xDGain";
            this.tb_xDGain.ReadOnly = true;
            this.tb_xDGain.Size = new System.Drawing.Size(62, 25);
            this.tb_xDGain.TabIndex = 26;
            // 
            // tb_xIGain
            // 
            this.tb_xIGain.Location = new System.Drawing.Point(133, 25);
            this.tb_xIGain.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_xIGain.Name = "tb_xIGain";
            this.tb_xIGain.ReadOnly = true;
            this.tb_xIGain.Size = new System.Drawing.Size(73, 25);
            this.tb_xIGain.TabIndex = 27;
            // 
            // groupBox12
            // 
            this.groupBox12.BackColor = System.Drawing.Color.Silver;
            this.groupBox12.Controls.Add(this.label21);
            this.groupBox12.Controls.Add(this.bt_PM_radiusSet);
            this.groupBox12.Controls.Add(this.tb_PM_radius);
            this.groupBox12.Controls.Add(this.label22);
            this.groupBox12.Controls.Add(this.bt_PM_numSet);
            this.groupBox12.Controls.Add(this.tb_PM_num);
            this.groupBox12.Location = new System.Drawing.Point(678, 40);
            this.groupBox12.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox12.Size = new System.Drawing.Size(389, 69);
            this.groupBox12.TabIndex = 41;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "PM설정";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(203, 32);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(37, 15);
            this.label21.TabIndex = 43;
            this.label21.Text = "반경";
            // 
            // bt_PM_radiusSet
            // 
            this.bt_PM_radiusSet.Location = new System.Drawing.Point(291, 29);
            this.bt_PM_radiusSet.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_PM_radiusSet.Name = "bt_PM_radiusSet";
            this.bt_PM_radiusSet.Size = new System.Drawing.Size(57, 29);
            this.bt_PM_radiusSet.TabIndex = 41;
            this.bt_PM_radiusSet.Text = "Set";
            this.bt_PM_radiusSet.UseVisualStyleBackColor = true;
            // 
            // tb_PM_radius
            // 
            this.tb_PM_radius.Location = new System.Drawing.Point(246, 29);
            this.tb_PM_radius.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_PM_radius.Name = "tb_PM_radius";
            this.tb_PM_radius.Size = new System.Drawing.Size(38, 25);
            this.tb_PM_radius.TabIndex = 42;
            this.tb_PM_radius.Text = "50";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(15, 35);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(57, 15);
            this.label22.TabIndex = 40;
            this.label22.Text = "점 갯수";
            // 
            // bt_PM_numSet
            // 
            this.bt_PM_numSet.Location = new System.Drawing.Point(121, 29);
            this.bt_PM_numSet.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_PM_numSet.Name = "bt_PM_numSet";
            this.bt_PM_numSet.Size = new System.Drawing.Size(57, 29);
            this.bt_PM_numSet.TabIndex = 35;
            this.bt_PM_numSet.Text = "Set";
            this.bt_PM_numSet.UseVisualStyleBackColor = true;
            // 
            // tb_PM_num
            // 
            this.tb_PM_num.Location = new System.Drawing.Point(73, 29);
            this.tb_PM_num.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_PM_num.Name = "tb_PM_num";
            this.tb_PM_num.Size = new System.Drawing.Size(38, 25);
            this.tb_PM_num.TabIndex = 39;
            this.tb_PM_num.Text = "5";
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.Silver;
            this.groupBox11.Location = new System.Drawing.Point(1073, 40);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox11.Size = new System.Drawing.Size(273, 451);
            this.groupBox11.TabIndex = 42;
            this.groupBox11.TabStop = false;
            // 
            // groupBox13
            // 
            this.groupBox13.BackColor = System.Drawing.Color.Silver;
            this.groupBox13.Location = new System.Drawing.Point(1073, 499);
            this.groupBox13.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox13.Size = new System.Drawing.Size(273, 375);
            this.groupBox13.TabIndex = 43;
            this.groupBox13.TabStop = false;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Silver;
            this.groupBox7.Controls.Add(this.bt_yEstop_Clr);
            this.groupBox7.Controls.Add(this.bt_yServoOn);
            this.groupBox7.Controls.Add(this.bt_yAlarmClr);
            this.groupBox7.Controls.Add(this.bt_yHome);
            this.groupBox7.Controls.Add(this.bt_yPosClr);
            this.groupBox7.Controls.Add(this.bt_yEstop);
            this.groupBox7.Controls.Add(this.tb_yVel);
            this.groupBox7.Controls.Add(this.tb_yAcc);
            this.groupBox7.Controls.Add(this.tb_yDec);
            this.groupBox7.Controls.Add(this.tb_yCommandPos);
            this.groupBox7.Controls.Add(this.tb_yFeedPos);
            this.groupBox7.Controls.Add(this.tb_yFeedVel);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Controls.Add(this.groupBox9);
            this.groupBox7.Controls.Add(this.groupBox10);
            this.groupBox7.ForeColor = System.Drawing.Color.Black;
            this.groupBox7.Location = new System.Drawing.Point(678, 499);
            this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox7.Size = new System.Drawing.Size(386, 375);
            this.groupBox7.TabIndex = 44;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Y축";
            // 
            // bt_yEstop_Clr
            // 
            this.bt_yEstop_Clr.Location = new System.Drawing.Point(264, 215);
            this.bt_yEstop_Clr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_yEstop_Clr.Name = "bt_yEstop_Clr";
            this.bt_yEstop_Clr.Size = new System.Drawing.Size(86, 29);
            this.bt_yEstop_Clr.TabIndex = 36;
            this.bt_yEstop_Clr.Text = "STOP Clr";
            this.bt_yEstop_Clr.UseVisualStyleBackColor = true;
            this.bt_yEstop_Clr.Click += new System.EventHandler(this.bt_yEstop_Clr_Click);
            // 
            // bt_yServoOn
            // 
            this.bt_yServoOn.Location = new System.Drawing.Point(264, 51);
            this.bt_yServoOn.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_yServoOn.Name = "bt_yServoOn";
            this.bt_yServoOn.Size = new System.Drawing.Size(86, 29);
            this.bt_yServoOn.TabIndex = 0;
            this.bt_yServoOn.Text = "Servo On";
            this.bt_yServoOn.UseVisualStyleBackColor = true;
            this.bt_yServoOn.Click += new System.EventHandler(this.bt_yServoOn_Click);
            // 
            // bt_yAlarmClr
            // 
            this.bt_yAlarmClr.Location = new System.Drawing.Point(264, 85);
            this.bt_yAlarmClr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_yAlarmClr.Name = "bt_yAlarmClr";
            this.bt_yAlarmClr.Size = new System.Drawing.Size(86, 29);
            this.bt_yAlarmClr.TabIndex = 1;
            this.bt_yAlarmClr.Text = "Alarm Clr";
            this.bt_yAlarmClr.UseVisualStyleBackColor = true;
            // 
            // bt_yHome
            // 
            this.bt_yHome.Location = new System.Drawing.Point(264, 119);
            this.bt_yHome.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_yHome.Name = "bt_yHome";
            this.bt_yHome.Size = new System.Drawing.Size(86, 29);
            this.bt_yHome.TabIndex = 2;
            this.bt_yHome.Text = "Home";
            this.bt_yHome.UseVisualStyleBackColor = true;
            this.bt_yHome.Click += new System.EventHandler(this.bt_yHome_Click);
            // 
            // bt_yPosClr
            // 
            this.bt_yPosClr.Location = new System.Drawing.Point(263, 171);
            this.bt_yPosClr.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_yPosClr.Name = "bt_yPosClr";
            this.bt_yPosClr.Size = new System.Drawing.Size(86, 29);
            this.bt_yPosClr.TabIndex = 3;
            this.bt_yPosClr.Text = "Pos Clr";
            this.bt_yPosClr.UseVisualStyleBackColor = true;
            this.bt_yPosClr.Click += new System.EventHandler(this.bt_yPosClr_Click);
            // 
            // bt_yEstop
            // 
            this.bt_yEstop.Location = new System.Drawing.Point(263, 260);
            this.bt_yEstop.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.bt_yEstop.Name = "bt_yEstop";
            this.bt_yEstop.Size = new System.Drawing.Size(86, 29);
            this.bt_yEstop.TabIndex = 5;
            this.bt_yEstop.Text = "ESTOP";
            this.bt_yEstop.UseVisualStyleBackColor = true;
            this.bt_yEstop.Click += new System.EventHandler(this.bt_yEstop_Click);
            // 
            // tb_yVel
            // 
            this.tb_yVel.Location = new System.Drawing.Point(162, 51);
            this.tb_yVel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_yVel.Name = "tb_yVel";
            this.tb_yVel.Size = new System.Drawing.Size(81, 25);
            this.tb_yVel.TabIndex = 12;
            this.tb_yVel.Text = "1000";
            // 
            // tb_yAcc
            // 
            this.tb_yAcc.Location = new System.Drawing.Point(162, 85);
            this.tb_yAcc.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_yAcc.Name = "tb_yAcc";
            this.tb_yAcc.Size = new System.Drawing.Size(81, 25);
            this.tb_yAcc.TabIndex = 13;
            this.tb_yAcc.Text = "1000";
            // 
            // tb_yDec
            // 
            this.tb_yDec.Location = new System.Drawing.Point(162, 121);
            this.tb_yDec.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_yDec.Name = "tb_yDec";
            this.tb_yDec.Size = new System.Drawing.Size(81, 25);
            this.tb_yDec.TabIndex = 14;
            this.tb_yDec.Text = "1000";
            // 
            // tb_yCommandPos
            // 
            this.tb_yCommandPos.Location = new System.Drawing.Point(162, 182);
            this.tb_yCommandPos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_yCommandPos.Name = "tb_yCommandPos";
            this.tb_yCommandPos.ReadOnly = true;
            this.tb_yCommandPos.Size = new System.Drawing.Size(81, 25);
            this.tb_yCommandPos.TabIndex = 15;
            // 
            // tb_yFeedPos
            // 
            this.tb_yFeedPos.Location = new System.Drawing.Point(162, 216);
            this.tb_yFeedPos.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_yFeedPos.Name = "tb_yFeedPos";
            this.tb_yFeedPos.ReadOnly = true;
            this.tb_yFeedPos.Size = new System.Drawing.Size(81, 25);
            this.tb_yFeedPos.TabIndex = 16;
            // 
            // tb_yFeedVel
            // 
            this.tb_yFeedVel.Location = new System.Drawing.Point(162, 250);
            this.tb_yFeedVel.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_yFeedVel.Name = "tb_yFeedVel";
            this.tb_yFeedVel.ReadOnly = true;
            this.tb_yFeedVel.Size = new System.Drawing.Size(81, 25);
            this.tb_yFeedVel.TabIndex = 17;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label12);
            this.groupBox8.Controls.Add(this.label13);
            this.groupBox8.Controls.Add(this.label14);
            this.groupBox8.Location = new System.Drawing.Point(32, 29);
            this.groupBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox8.Size = new System.Drawing.Size(225, 130);
            this.groupBox8.TabIndex = 29;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "[파라미터]";
            // 
            // label12
            // 
            this.label12.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label12.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label12.Location = new System.Drawing.Point(7, 90);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 29);
            this.label12.TabIndex = 32;
            this.label12.Text = "Deceleration";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label13.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label13.Location = new System.Drawing.Point(7, 55);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 29);
            this.label13.TabIndex = 31;
            this.label13.Text = "Acceleration";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label14.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label14.Location = new System.Drawing.Point(7, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(98, 29);
            this.label14.TabIndex = 30;
            this.label14.Text = "Velocity";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label15);
            this.groupBox9.Controls.Add(this.label16);
            this.groupBox9.Controls.Add(this.label17);
            this.groupBox9.Location = new System.Drawing.Point(32, 164);
            this.groupBox9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox9.Size = new System.Drawing.Size(225, 125);
            this.groupBox9.TabIndex = 33;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "[모니터링]";
            // 
            // label15
            // 
            this.label15.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label15.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label15.Location = new System.Drawing.Point(7, 86);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(98, 29);
            this.label15.TabIndex = 35;
            this.label15.Text = "Feedback Vel";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label16.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label16.Location = new System.Drawing.Point(7, 51);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(98, 29);
            this.label16.TabIndex = 34;
            this.label16.Text = "Feedback Pos";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label17.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label17.Location = new System.Drawing.Point(7, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(117, 29);
            this.label17.TabIndex = 33;
            this.label17.Text = "Command Pos";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label18);
            this.groupBox10.Controls.Add(this.label19);
            this.groupBox10.Controls.Add(this.label20);
            this.groupBox10.Controls.Add(this.tb_yPGain);
            this.groupBox10.Controls.Add(this.tb_yDGain);
            this.groupBox10.Controls.Add(this.tb_yIGain);
            this.groupBox10.Location = new System.Drawing.Point(32, 296);
            this.groupBox10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox10.Size = new System.Drawing.Size(318, 70);
            this.groupBox10.TabIndex = 34;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "[모니터링 PID]";
            // 
            // label18
            // 
            this.label18.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label18.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label18.Location = new System.Drawing.Point(208, 26);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(27, 26);
            this.label18.TabIndex = 38;
            this.label18.Text = "D :";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label19.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label19.Location = new System.Drawing.Point(106, 26);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(29, 26);
            this.label19.TabIndex = 37;
            this.label19.Text = "I :";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label20.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label20.Location = new System.Drawing.Point(7, 28);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(27, 26);
            this.label20.TabIndex = 36;
            this.label20.Text = "P :";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tb_yPGain
            // 
            this.tb_yPGain.Location = new System.Drawing.Point(38, 25);
            this.tb_yPGain.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_yPGain.Name = "tb_yPGain";
            this.tb_yPGain.ReadOnly = true;
            this.tb_yPGain.Size = new System.Drawing.Size(62, 25);
            this.tb_yPGain.TabIndex = 28;
            // 
            // tb_yDGain
            // 
            this.tb_yDGain.Location = new System.Drawing.Point(240, 25);
            this.tb_yDGain.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_yDGain.Name = "tb_yDGain";
            this.tb_yDGain.ReadOnly = true;
            this.tb_yDGain.Size = new System.Drawing.Size(62, 25);
            this.tb_yDGain.TabIndex = 26;
            // 
            // tb_yIGain
            // 
            this.tb_yIGain.Location = new System.Drawing.Point(131, 25);
            this.tb_yIGain.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_yIGain.Name = "tb_yIGain";
            this.tb_yIGain.ReadOnly = true;
            this.tb_yIGain.Size = new System.Drawing.Size(69, 25);
            this.tb_yIGain.TabIndex = 27;
            // 
            // lb_connect_state
            // 
            this.lb_connect_state.AutoSize = true;
            this.lb_connect_state.BackColor = System.Drawing.Color.DimGray;
            this.lb_connect_state.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lb_connect_state.Location = new System.Drawing.Point(15, 16);
            this.lb_connect_state.Name = "lb_connect_state";
            this.lb_connect_state.Size = new System.Drawing.Size(162, 20);
            this.lb_connect_state.TabIndex = 45;
            this.lb_connect_state.Text = "Disconnected...";
            // 
            // groupBox14
            // 
            this.groupBox14.BackColor = System.Drawing.Color.Silver;
            this.groupBox14.Controls.Add(this.button1);
            this.groupBox14.Location = new System.Drawing.Point(511, 31);
            this.groupBox14.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Padding = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.groupBox14.Size = new System.Drawing.Size(160, 49);
            this.groupBox14.TabIndex = 46;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "CAM";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(32, 14);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(86, 29);
            this.button1.TabIndex = 0;
            this.button1.Text = "CAM 송출";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(1472, 858);
            this.Controls.Add(this.groupBox14);
            this.Controls.Add(this.lb_connect_state);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.gb_xGroup);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pl_stage);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.gb_xGroup.ResumeLayout(false);
            this.gb_xGroup.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel pl_stage;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button bt_disconnect;
        private System.Windows.Forms.Button bt_connect;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bt_Normal_Move;
        private System.Windows.Forms.TextBox tb_Normal_Move_YPos;
        private System.Windows.Forms.TextBox tb_Normal_Move_XPos;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.RadioButton rb_CAM;
        private System.Windows.Forms.RadioButton rb_PM;
        private System.Windows.Forms.RadioButton rb_PTP;
        private System.Windows.Forms.RadioButton rb_CP;
        private System.Windows.Forms.GroupBox gb_xGroup;
        public System.Windows.Forms.Button bt_xServoOn;
        private System.Windows.Forms.Button bt_xAlarmClr;
        private System.Windows.Forms.Button bt_xHome;
        private System.Windows.Forms.Button bt_xPosClr;
        private System.Windows.Forms.Button bt_xEstop;
        private System.Windows.Forms.TextBox tb_xVel;
        private System.Windows.Forms.TextBox tb_xAcc;
        private System.Windows.Forms.TextBox tb_xDec;
        private System.Windows.Forms.TextBox tb_xCommandPos;
        private System.Windows.Forms.TextBox tb_xFeedPos;
        private System.Windows.Forms.TextBox tb_xFeedVel;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.TextBox tb_xPGain;
        public System.Windows.Forms.TextBox tb_xDGain;
        public System.Windows.Forms.TextBox tb_xIGain;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label21;
        public System.Windows.Forms.Button bt_PM_radiusSet;
        public System.Windows.Forms.TextBox tb_PM_radius;
        private System.Windows.Forms.Label label22;
        public System.Windows.Forms.Button bt_PM_numSet;
        public System.Windows.Forms.TextBox tb_PM_num;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.RadioButton rb_Line;
        private System.Windows.Forms.GroupBox groupBox7;
        public System.Windows.Forms.Button bt_yServoOn;
        private System.Windows.Forms.Button bt_yAlarmClr;
        private System.Windows.Forms.Button bt_yHome;
        private System.Windows.Forms.Button bt_yPosClr;
        private System.Windows.Forms.Button bt_yEstop;
        private System.Windows.Forms.TextBox tb_yVel;
        private System.Windows.Forms.TextBox tb_yAcc;
        private System.Windows.Forms.TextBox tb_yDec;
        private System.Windows.Forms.TextBox tb_yCommandPos;
        private System.Windows.Forms.TextBox tb_yFeedPos;
        private System.Windows.Forms.TextBox tb_yFeedVel;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        public System.Windows.Forms.TextBox tb_yPGain;
        public System.Windows.Forms.TextBox tb_yDGain;
        public System.Windows.Forms.TextBox tb_yIGain;
        private System.Windows.Forms.Label lb_connect_state;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button bt_stop;
        private System.Windows.Forms.Button bt_Graph;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button bt_xEstop_Clr;
        private System.Windows.Forms.Button bt_yEstop_Clr;
    }
}

